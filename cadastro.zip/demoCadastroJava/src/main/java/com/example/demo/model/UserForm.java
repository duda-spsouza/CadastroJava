package com.example.demo.model;

public class UserForm {
    
    private Long UserId;
    private String UserNome;
    private String UserCredito;
    private String UserRisco;
    private String UserTaxa;
	public Long getUserId() {
		return UserId;
	}
	public void setUserId(Long userId) {
		UserId = userId;
	}
	public String getUserNome() {
		return UserNome;
	}
	public void setUserNome(String userNome) {
		UserNome = userNome;
	}
	public String getUserCredito() {
		return UserCredito;
	}
	public void setUserCredito(String userCredito) {
		UserCredito = userCredito;
	}
	public String getUserRisco() {
		return UserRisco;
	}
	public void setUserRisco(String userRisco) {
		UserRisco = userRisco;
	}
	public String getUserTaxa() {
		return UserTaxa;
	}
	public void setUserTaxa(String userTaxa) {
		UserTaxa = userTaxa;
	}
 
   
}